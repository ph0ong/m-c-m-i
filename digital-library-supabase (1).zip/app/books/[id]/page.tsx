"use client"

import { useState } from "react"
import { ArrowLeft, Star, Download, BookOpen, Share2, Heart, Eye, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"

const bookData = {
  id: 1,
  title: "Lập trình Python cơ bản",
  author: "Nguyễn Văn A",
  category: "Công nghệ",
  rating: 4.8,
  totalRatings: 245,
  downloads: 1250,
  views: 5420,
  pages: 320,
  year: 2023,
  publisher: "NXB Giáo dục",
  language: "Tiếng Việt",
  format: "PDF",
  size: "15.2 MB",
  cover: "/placeholder.svg?height=400&width=300",
  description:
    "Cuốn sách này cung cấp kiến thức cơ bản về lập trình Python, từ cú pháp cơ bản đến các khái niệm nâng cao. Được viết bởi các chuyên gia có nhiều năm kinh nghiệm trong lĩnh vực lập trình, cuốn sách phù hợp cho cả người mới bắt đầu và những người đã có kinh nghiệm muốn củng cố kiến thức.",
  tableOfContents: [
    "Chương 1: Giới thiệu về Python",
    "Chương 2: Cú pháp cơ bản",
    "Chương 3: Cấu trúc dữ liệu",
    "Chương 4: Hàm và Module",
    "Chương 5: Lập trình hướng đối tượng",
    "Chương 6: Xử lý file và exception",
    "Chương 7: Thư viện chuẩn",
    "Chương 8: Dự án thực hành",
  ],
  reviews: [
    {
      id: 1,
      user: "Trần Văn B",
      rating: 5,
      date: "2024-01-15",
      comment: "Cuốn sách rất hay, giải thích dễ hiểu và có nhiều ví dụ thực tế.",
    },
    {
      id: 2,
      user: "Lê Thị C",
      rating: 4,
      date: "2024-01-10",
      comment: "Nội dung tốt nhưng có thể cần thêm bài tập thực hành.",
    },
  ],
}

const relatedBooks = [
  {
    id: 2,
    title: "Python nâng cao",
    author: "Phạm Văn D",
    rating: 4.6,
    cover: "/placeholder.svg?height=150&width=100",
  },
  {
    id: 3,
    title: "Web Development với Python",
    author: "Hoàng Thị E",
    rating: 4.7,
    cover: "/placeholder.svg?height=150&width=100",
  },
  {
    id: 4,
    title: "Data Science với Python",
    author: "Ngô Văn F",
    rating: 4.9,
    cover: "/placeholder.svg?height=150&width=100",
  },
]

export default function BookDetailPage() {
  const [isFavorite, setIsFavorite] = useState(false)
  const [readingProgress, setReadingProgress] = useState(0)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Thư viện số</h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="outline">Đăng nhập</Button>
              <Button>Đăng ký</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Link href="/books" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Quay lại danh sách sách
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Book Info */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-8">
              <div className="flex flex-col md:flex-row gap-8">
                {/* Book Cover */}
                <div className="flex-shrink-0">
                  <img
                    src={bookData.cover || "/placeholder.svg"}
                    alt={bookData.title}
                    className="w-64 h-80 object-cover rounded-lg shadow-lg mx-auto md:mx-0"
                  />
                </div>

                {/* Book Details */}
                <div className="flex-1">
                  <Badge className="mb-4">{bookData.category}</Badge>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{bookData.title}</h1>
                  <p className="text-xl text-gray-600 mb-4">Tác giả: {bookData.author}</p>

                  {/* Rating */}
                  <div className="flex items-center gap-4 mb-6">
                    <div className="flex items-center">
                      <Star className="h-5 w-5 text-yellow-400 mr-1" />
                      <span className="font-semibold">{bookData.rating}</span>
                      <span className="text-gray-500 ml-1">({bookData.totalRatings} đánh giá)</span>
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Download className="h-4 w-4 mr-1" />
                      {bookData.downloads} lượt tải
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Eye className="h-4 w-4 mr-1" />
                      {bookData.views} lượt xem
                    </div>
                  </div>

                  {/* Book Info */}
                  <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                    <div>
                      <span className="text-gray-500">Số trang:</span>
                      <span className="ml-2 font-medium">{bookData.pages}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Năm xuất bản:</span>
                      <span className="ml-2 font-medium">{bookData.year}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Nhà xuất bản:</span>
                      <span className="ml-2 font-medium">{bookData.publisher}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Ngôn ngữ:</span>
                      <span className="ml-2 font-medium">{bookData.language}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Định dạng:</span>
                      <span className="ml-2 font-medium">{bookData.format}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">Kích thước:</span>
                      <span className="ml-2 font-medium">{bookData.size}</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap gap-4">
                    <Button size="lg" className="flex-1 min-w-32">
                      <BookOpen className="h-5 w-5 mr-2" />
                      Đọc ngay
                    </Button>
                    <Button variant="outline" size="lg">
                      <Download className="h-5 w-5 mr-2" />
                      Tải về
                    </Button>
                    <Button variant="outline" size="lg" onClick={() => setIsFavorite(!isFavorite)}>
                      <Heart className={`h-5 w-5 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                    </Button>
                    <Button variant="outline" size="lg">
                      <Share2 className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="mt-8">
              <Tabs defaultValue="description" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="description">Mô tả</TabsTrigger>
                  <TabsTrigger value="contents">Mục lục</TabsTrigger>
                  <TabsTrigger value="reviews">Đánh giá</TabsTrigger>
                </TabsList>

                <TabsContent value="description" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Mô tả sách</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 leading-relaxed">{bookData.description}</p>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="contents" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Mục lục</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-3">
                        {bookData.tableOfContents.map((chapter, index) => (
                          <li key={index} className="flex items-center text-gray-700">
                            <FileText className="h-4 w-4 mr-3 text-blue-600" />
                            {chapter}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="reviews" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Đánh giá từ độc giả</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {bookData.reviews.map((review) => (
                          <div key={review.id} className="border-b pb-4 last:border-b-0">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-semibold">{review.user}</h4>
                              <div className="flex items-center">
                                <Star className="h-4 w-4 text-yellow-400 mr-1" />
                                <span>{review.rating}</span>
                              </div>
                            </div>
                            <p className="text-gray-600 text-sm mb-2">{review.date}</p>
                            <p className="text-gray-700">{review.comment}</p>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Reading Progress */}
            <Card>
              <CardHeader>
                <CardTitle>Tiến độ đọc</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Progress value={readingProgress} className="w-full" />
                  <p className="text-sm text-gray-600">
                    Đã đọc {readingProgress}% ({Math.floor((bookData.pages * readingProgress) / 100)} / {bookData.pages}{" "}
                    trang)
                  </p>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setReadingProgress(Math.min(100, readingProgress + 10))}
                  >
                    Tiếp tục đọc
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Related Books */}
            <Card>
              <CardHeader>
                <CardTitle>Sách liên quan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {relatedBooks.map((book) => (
                    <div key={book.id} className="flex gap-3">
                      <img
                        src={book.cover || "/placeholder.svg"}
                        alt={book.title}
                        className="w-16 h-20 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium text-sm line-clamp-2">{book.title}</h4>
                        <p className="text-xs text-gray-600 mt-1">{book.author}</p>
                        <div className="flex items-center mt-1">
                          <Star className="h-3 w-3 text-yellow-400 mr-1" />
                          <span className="text-xs">{book.rating}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
