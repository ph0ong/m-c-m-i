import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"

// Mock authentication - trong thực tế sẽ sử dụng JWT và hash password
const users = [
  {
    id: 1,
    email: "admin@library.com",
    password: "admin123", // In real app, this would be hashed
    name: "Admin User",
    role: "admin",
  },
  {
    id: 2,
    email: "user@library.com",
    password: "user123",
    name: "Regular User",
    role: "user",
  },
]

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json({ success: false, error: "Email and password are required" }, { status: 400 })
    }

    // Find user
    const user = users.find((u) => u.email === email && u.password === password)

    if (!user) {
      return NextResponse.json({ success: false, error: "Invalid credentials" }, { status: 401 })
    }

    // Create session token (in real app, use JWT)
    const sessionToken = `session_${user.id}_${Date.now()}`

    // Set cookie
    const cookieStore = cookies()
    cookieStore.set("session", sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    })

    // Return user data (without password)
    const { password: _, ...userData } = user

    return NextResponse.json({
      success: true,
      data: {
        user: userData,
        token: sessionToken,
      },
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}
