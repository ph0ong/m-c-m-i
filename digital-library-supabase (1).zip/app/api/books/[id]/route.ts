import { type NextRequest, NextResponse } from "next/server"

// Mock data - trong thực tế sẽ kết nối với database
const books = [
  {
    id: 1,
    title: "Lập trình Python cơ bản",
    author: "Nguyễn Văn A",
    category: "Công nghệ",
    rating: 4.8,
    totalRatings: 245,
    downloads: 1250,
    views: 5420,
    pages: 320,
    year: 2023,
    publisher: "NXB Giáo dục",
    language: "Tiếng Việt",
    format: "PDF",
    size: "15.2 MB",
    cover: "/placeholder.svg?height=400&width=300",
    description: "Hướng dẫn học Python từ cơ bản đến nâng cao với các ví dụ thực tế",
    tableOfContents: [
      "Chương 1: Giới thiệu về Python",
      "Chương 2: Cú pháp cơ bản",
      "Chương 3: Cấu trúc dữ liệu",
      "Chương 4: Hàm và Module",
      "Chương 5: Lập trình hướng đối tượng",
      "Chương 6: Xử lý file và exception",
      "Chương 7: Thư viện chuẩn",
      "Chương 8: Dự án thực hành",
    ],
    isPremium: false,
    downloadUrl: "/files/python-basic.pdf",
    createdAt: "2024-01-15T00:00:00Z",
    updatedAt: "2024-01-15T00:00:00Z",
  },
]

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const bookId = Number.parseInt(params.id)
    const book = books.find((b) => b.id === bookId)

    if (!book) {
      return NextResponse.json({ success: false, error: "Book not found" }, { status: 404 })
    }

    // Increment view count (in real app, this would be in database)
    book.views += 1

    return NextResponse.json({
      success: true,
      data: book,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const bookId = Number.parseInt(params.id)
    const bookIndex = books.findIndex((b) => b.id === bookId)

    if (bookIndex === -1) {
      return NextResponse.json({ success: false, error: "Book not found" }, { status: 404 })
    }

    const body = await request.json()
    const updatedBook = {
      ...books[bookIndex],
      ...body,
      id: bookId, // Ensure ID doesn't change
      updatedAt: new Date().toISOString(),
    }

    books[bookIndex] = updatedBook

    return NextResponse.json({
      success: true,
      data: updatedBook,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const bookId = Number.parseInt(params.id)
    const bookIndex = books.findIndex((b) => b.id === bookId)

    if (bookIndex === -1) {
      return NextResponse.json({ success: false, error: "Book not found" }, { status: 404 })
    }

    const deletedBook = books.splice(bookIndex, 1)[0]

    return NextResponse.json({
      success: true,
      data: deletedBook,
      message: "Book deleted successfully",
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}
