import { type NextRequest, NextResponse } from "next/server"

// Mock user data
const users = [
  {
    id: 1,
    name: "Nguyễn Văn A",
    email: "nguyenvana@email.com",
    role: "user",
    avatar: "/placeholder.svg?height=100&width=100",
    joinDate: "2024-01-01T00:00:00Z",
    lastLogin: "2024-01-20T10:30:00Z",
    booksRead: 15,
    favoriteBooks: [1, 3, 5],
    readingProgress: {
      1: { currentPage: 45, totalPages: 320, lastRead: "2024-01-20T09:15:00Z" },
      3: { currentPage: 120, totalPages: 280, lastRead: "2024-01-19T14:22:00Z" },
    },
    subscription: {
      plan: "premium",
      status: "active",
      startDate: "2024-01-01T00:00:00Z",
      endDate: "2024-12-31T23:59:59Z",
    },
    preferences: {
      theme: "light",
      fontSize: 16,
      notifications: true,
      autoBookmark: true,
    },
    isActive: true,
    createdAt: "2024-01-01T00:00:00Z",
    updatedAt: "2024-01-20T10:30:00Z",
  },
  {
    id: 2,
    name: "Trần Thị B",
    email: "tranthib@email.com",
    role: "author",
    avatar: "/placeholder.svg?height=100&width=100",
    joinDate: "2023-12-15T00:00:00Z",
    lastLogin: "2024-01-19T16:45:00Z",
    booksRead: 8,
    favoriteBooks: [2, 4],
    readingProgress: {},
    subscription: {
      plan: "free",
      status: "active",
      startDate: "2023-12-15T00:00:00Z",
      endDate: null,
    },
    preferences: {
      theme: "dark",
      fontSize: 18,
      notifications: false,
      autoBookmark: false,
    },
    isActive: true,
    createdAt: "2023-12-15T00:00:00Z",
    updatedAt: "2024-01-19T16:45:00Z",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const role = searchParams.get("role")
    const search = searchParams.get("search")

    let filteredUsers = [...users]

    // Filter by role
    if (role && role !== "all") {
      filteredUsers = filteredUsers.filter((user) => user.role === role)
    }

    // Filter by search query
    if (search) {
      filteredUsers = filteredUsers.filter(
        (user) =>
          user.name.toLowerCase().includes(search.toLowerCase()) ||
          user.email.toLowerCase().includes(search.toLowerCase()),
      )
    }

    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + limit
    const paginatedUsers = filteredUsers.slice(startIndex, endIndex)

    // Remove sensitive data
    const safeUsers = paginatedUsers.map((user) => {
      const { ...safeUser } = user
      return safeUser
    })

    return NextResponse.json({
      success: true,
      data: {
        users: safeUsers,
        pagination: {
          currentPage: page,
          totalPages: Math.ceil(filteredUsers.length / limit),
          totalUsers: filteredUsers.length,
          hasNext: endIndex < filteredUsers.length,
          hasPrev: page > 1,
        },
      },
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required fields
    const requiredFields = ["name", "email"]
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json({ success: false, error: `Missing required field: ${field}` }, { status: 400 })
      }
    }

    // Check if email already exists
    const existingUser = users.find((user) => user.email === body.email)
    if (existingUser) {
      return NextResponse.json({ success: false, error: "Email already exists" }, { status: 409 })
    }

    // Create new user
    const newUser = {
      id: users.length + 1,
      name: body.name,
      email: body.email,
      role: body.role || "user",
      avatar: body.avatar || "/placeholder.svg?height=100&width=100",
      joinDate: new Date().toISOString(),
      lastLogin: null,
      booksRead: 0,
      favoriteBooks: [],
      readingProgress: {},
      subscription: {
        plan: "free",
        status: "active",
        startDate: new Date().toISOString(),
        endDate: null,
      },
      preferences: {
        theme: "light",
        fontSize: 16,
        notifications: true,
        autoBookmark: true,
      },
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    users.push(newUser)

    return NextResponse.json(
      {
        success: true,
        data: newUser,
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json({ success: false, error: "Invalid JSON data" }, { status: 400 })
  }
}
