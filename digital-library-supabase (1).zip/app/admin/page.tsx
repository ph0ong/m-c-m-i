"use client"

import { useState } from "react"
import { BookOpen, Users, Settings, Plus, Search, Edit, Trash2, Eye, Download, TrendingUp, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

const stats = [
  { title: "Tổng số sách", value: "2,847", change: "+12%", icon: BookOpen, color: "text-blue-600" },
  { title: "Người dùng", value: "15,234", change: "+8%", icon: Users, color: "text-green-600" },
  { title: "Lượt tải", value: "45,678", change: "+23%", icon: Download, color: "text-purple-600" },
  { title: "Doanh thu", value: "₫125M", change: "+15%", icon: TrendingUp, color: "text-orange-600" },
]

const recentBooks = [
  {
    id: 1,
    title: "AI và Machine Learning",
    author: "Trần Văn A",
    category: "Công nghệ",
    status: "Đã duyệt",
    downloads: 1250,
    rating: 4.8,
    uploadDate: "2024-01-15",
  },
  {
    id: 2,
    title: "Kinh tế số",
    author: "Nguyễn Thị B",
    category: "Kinh tế",
    status: "Chờ duyệt",
    downloads: 890,
    rating: 4.6,
    uploadDate: "2024-01-14",
  },
  {
    id: 3,
    title: "Văn học đương đại",
    author: "Lê Văn C",
    category: "Văn học",
    status: "Đã duyệt",
    downloads: 2100,
    rating: 4.9,
    uploadDate: "2024-01-13",
  },
]

const users = [
  {
    id: 1,
    name: "Nguyễn Văn A",
    email: "nguyenvana@email.com",
    role: "Người dùng",
    joinDate: "2024-01-01",
    booksRead: 15,
    status: "Hoạt động",
  },
  {
    id: 2,
    name: "Trần Thị B",
    email: "tranthib@email.com",
    role: "Tác giả",
    joinDate: "2023-12-15",
    booksRead: 8,
    status: "Hoạt động",
  },
]

export default function AdminDashboard() {
  const [selectedTab, setSelectedTab] = useState("overview")
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddBookOpen, setIsAddBookOpen] = useState(false)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                Cài đặt
              </Button>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Thêm sách
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Tổng quan</TabsTrigger>
            <TabsTrigger value="books">Quản lý sách</TabsTrigger>
            <TabsTrigger value="users">Người dùng</TabsTrigger>
            <TabsTrigger value="analytics">Thống kê</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                        <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                        <p className="text-sm text-green-600">{stat.change} so với tháng trước</p>
                      </div>
                      <stat.icon className={`h-8 w-8 ${stat.color}`} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Sách mới nhất</CardTitle>
                  <CardDescription>Các sách được thêm gần đây</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentBooks.slice(0, 3).map((book) => (
                      <div key={book.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{book.title}</p>
                          <p className="text-sm text-gray-600">{book.author}</p>
                        </div>
                        <Badge variant={book.status === "Đã duyệt" ? "default" : "secondary"}>{book.status}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Hoạt động gần đây</CardTitle>
                  <CardDescription>Các hoạt động trong hệ thống</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <p className="text-sm">Người dùng mới đăng ký: Nguyễn Văn D</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <p className="text-sm">Sách mới được tải lên: "Python Advanced"</p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                      <p className="text-sm">Đánh giá mới: 5 sao cho "AI Basics"</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Books Management Tab */}
          <TabsContent value="books" className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-2xl font-bold">Quản lý sách</h3>
              <Dialog open={isAddBookOpen} onOpenChange={setIsAddBookOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Thêm sách mới
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Thêm sách mới</DialogTitle>
                    <DialogDescription>Nhập thông tin sách để thêm vào thư viện</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="title">Tiêu đề</Label>
                        <Input id="title" placeholder="Nhập tiêu đề sách" />
                      </div>
                      <div>
                        <Label htmlFor="author">Tác giả</Label>
                        <Input id="author" placeholder="Nhập tên tác giả" />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="category">Danh mục</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Chọn danh mục" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="tech">Công nghệ</SelectItem>
                            <SelectItem value="economy">Kinh tế</SelectItem>
                            <SelectItem value="literature">Văn học</SelectItem>
                            <SelectItem value="science">Khoa học</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="pages">Số trang</Label>
                        <Input id="pages" type="number" placeholder="320" />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="description">Mô tả</Label>
                      <Textarea id="description" placeholder="Nhập mô tả sách" rows={3} />
                    </div>
                    <div>
                      <Label htmlFor="cover">Ảnh bìa</Label>
                      <Input id="cover" type="file" accept="image/*" />
                    </div>
                    <div>
                      <Label htmlFor="file">File PDF</Label>
                      <Input id="file" type="file" accept=".pdf" />
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsAddBookOpen(false)}>
                      Hủy
                    </Button>
                    <Button onClick={() => setIsAddBookOpen(false)}>Thêm sách</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Search and Filter */}
            <div className="flex gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Tìm kiếm sách..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Lọc theo danh mục" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  <SelectItem value="tech">Công nghệ</SelectItem>
                  <SelectItem value="economy">Kinh tế</SelectItem>
                  <SelectItem value="literature">Văn học</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Books Table */}
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sách</TableHead>
                    <TableHead>Tác giả</TableHead>
                    <TableHead>Danh mục</TableHead>
                    <TableHead>Trạng thái</TableHead>
                    <TableHead>Lượt tải</TableHead>
                    <TableHead>Đánh giá</TableHead>
                    <TableHead>Thao tác</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentBooks.map((book) => (
                    <TableRow key={book.id}>
                      <TableCell className="font-medium">{book.title}</TableCell>
                      <TableCell>{book.author}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{book.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={book.status === "Đã duyệt" ? "default" : "secondary"}>{book.status}</Badge>
                      </TableCell>
                      <TableCell>{book.downloads}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 mr-1" />
                          {book.rating}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-2xl font-bold">Quản lý người dùng</h3>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Thêm người dùng
              </Button>
            </div>

            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tên</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Vai trò</TableHead>
                    <TableHead>Ngày tham gia</TableHead>
                    <TableHead>Sách đã đọc</TableHead>
                    <TableHead>Trạng thái</TableHead>
                    <TableHead>Thao tác</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{user.role}</Badge>
                      </TableCell>
                      <TableCell>{user.joinDate}</TableCell>
                      <TableCell>{user.booksRead}</TableCell>
                      <TableCell>
                        <Badge variant="default">{user.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <h3 className="text-2xl font-bold">Thống kê và báo cáo</h3>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Lượt truy cập theo tháng</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    Biểu đồ lượt truy cập (Chart.js integration)
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Danh mục phổ biến</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Công nghệ</span>
                      <span className="font-semibold">35%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Kinh tế</span>
                      <span className="font-semibold">25%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Văn học</span>
                      <span className="font-semibold">20%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Khoa học</span>
                      <span className="font-semibold">20%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
