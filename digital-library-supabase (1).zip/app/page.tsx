
'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

type Book = {
  id: number
  title: string
  author: string
  cover_url?: string
  pdf_url?: string
}

export default function Home() {
  const [books, setBooks] = useState<Book[]>([])

  useEffect(() => {
    const fetchBooks = async () => {
      const { data, error } = await supabase.from('books').select('*')
      if (error) console.error(error)
      else setBooks(data || [])
    }
    fetchBooks()
  }, [])

  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold mb-4">📚 Danh sách tài liệu</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {books.map((book) => (
          <div key={book.id} className="border p-4 rounded-lg shadow-sm bg-white">
            <h2 className="text-lg font-semibold">{book.title}</h2>
            <p className="text-sm text-gray-600">Tác giả: {book.author}</p>
            {book.cover_url && <img src={book.cover_url} alt={book.title} className="w-full mt-2 rounded" />}
            {book.pdf_url && (
              <a href={book.pdf_url} target="_blank" className="text-blue-600 underline mt-2 block">
                Xem PDF
              </a>
            )}
          </div>
        ))}
      </div>
    </main>
  )
}
